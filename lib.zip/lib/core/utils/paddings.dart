class AppPaddings{

}